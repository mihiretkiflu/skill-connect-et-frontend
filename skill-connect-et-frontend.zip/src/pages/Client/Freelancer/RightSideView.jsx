import React from "react";
import CustomCard from "../../../components/CustomCard";

export default function RightSideView() {
  return (
    <CustomCard
      title={"Experienced React developer for fixing few bugs"}
      subTitle={"Posted 2 hours ago"}
    >
      djakfljsdkfjks
    </CustomCard>
  );
}
