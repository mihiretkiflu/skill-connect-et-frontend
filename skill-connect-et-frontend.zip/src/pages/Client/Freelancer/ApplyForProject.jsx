import React from "react";

export default function ApplyForProject() {
  return <div>ApplyForProject</div>;
}
